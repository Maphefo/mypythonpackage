# mypackage
This package consists of two files recursion.py and sorting.py consisting of 4 and 3 functions respectively.

recursion.py:
 The first function returns the sum of an array, the second function returns nth term in fibonacci sequence, the third function returns the factorial of a number, the fourth function returns the reverse of a word.

sorting.py:
The first function is a bubble_sort, the second function is a merge_sort, the third  function is a  quick_sort, that return an array of items, sorted in ascending order.

## building this package locally
`python setup.py sdist`

## installing this from GitHub
`pip install git+https://github.com/Maphefo/mypackage.git`

## updating this package from GitHub
`pip install --upgrade git+https://github.com/Maphefo/mypackage.git`
